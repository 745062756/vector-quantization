Standard Homework: 

Compile: Modified file: Main.cpp and Image.cpp. Please put these 2 files into original hw1 starter code and compile regularly.

Exe: Image.exe [file_name at same folder] [2] [codebook size]

Note: 1. please wait patiently during exe (cap by iteration limits). 
2. If exact exe file name is not Image.exe (I remember wrongly), please correct it since I never change exe file name in original starter code. Feel free to email me regarding
to any clarification. Thanks for your work.